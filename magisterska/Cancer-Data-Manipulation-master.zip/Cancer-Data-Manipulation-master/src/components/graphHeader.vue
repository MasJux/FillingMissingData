<template>
    <div class="header">
        <div class="header__title text-h4">
            Wisconsin cancer graph
        </div>
    </div>
</template>