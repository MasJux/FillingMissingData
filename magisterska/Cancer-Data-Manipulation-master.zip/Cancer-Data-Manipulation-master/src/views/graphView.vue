<template>
    <div class="graph">
        <DataGraph />
    </div>
</template>
<script setup>
import DataGraph from '@/components/dataGraph.vue';

</script>
<style scoped lang="scss">
.graph {
    width: 100%;
    max-width: 1000px;
}
</style>