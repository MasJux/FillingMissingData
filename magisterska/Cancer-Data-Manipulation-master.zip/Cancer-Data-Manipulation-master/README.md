![image](https://github.com/A1wol/Cancer-Data-Manipulation/assets/103753811/ca97b163-5f2c-46f3-b817-1acf5193a711)
![image](https://github.com/A1wol/Cancer-Data-Manipulation/assets/103753811/8e39c2eb-009f-4575-9610-1e962fbb39f1)
![image](https://github.com/A1wol/Cancer-Data-Manipulation/assets/103753811/3aaf24d8-5663-4ad4-a6cc-36900f3d283d)

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```
